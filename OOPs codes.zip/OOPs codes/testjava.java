import java.util.Arrays;
import java.util.Collections;
class testjava{
    public static void main(String args[]){
        String arr[]={"hello","apple","vinay"};
        Arrays.sort(arr,Collections.reverseOrder());
        System.out.println(Arrays.toString(arr));
    }
}