abstract class shape{
    abstract double getArea();
    abstract double getVolume();
}
class square extends shape{
    int s;
    square(int s){
        this.s=s;
    }
    double getArea(){
        return s*s;
    }
    double getVolume(){
        return 4*s;
    }
}
class circle extends shape{
    int r;
    circle(int rad){
        r=rad;
    }
    double getArea(){
        return 3.14*r*r;
    }
    double getVolume(){
        return 2*3.14*r;
    }
}
class cube extends shape{
    int s;
    cube(int s){
        this.s=s;
    }
    double getArea(){
        return 6*s*s;
    }
    double getVolume(){
        return s*s*s;
    }
}
class sphere extends shape{
    int r;
    sphere(int s){
       r=s;
    }
    double getArea(){
        return 4*3.14*r*r;
    }
    double getVolume(){
        return ((double)4/3)*3.14*r*r*r;
    }
}
class first{
    public static void main(String args[]){
        square s=new square(4);
        System.out.println(s.getArea());
        System.out.println(s.getVolume());
        circle c=new circle(4);
        System.out.println(c.getArea());
        System.out.println(c.getVolume());
        cube cu=new cube(4);
        System.out.println(cu.getArea());
        System.out.println(cu.getVolume());
        sphere sp=new sphere(4);
        System.out.println(sp.getArea());
        System.out.println(sp.getVolume());
    }
}