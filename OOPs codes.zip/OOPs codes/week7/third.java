interface payable{
    void getAmount(int m,int n);
}
class calculate implements payable{
    public void getAmount(int m,int n){
        System.out.println("Amount paid to employee= "+(m*100));
        System.out.println("Amount paid to Invoice= "+((m*100)+n));
        //invoice = amt paid to employee + extra charges
    }
}
class third{
    public static void main(String[] args) {
        calculate c=new calculate();
        c.getAmount(100, 29);
    }
}