//  Create an abstract class Employee with methods getAmount() which displays the 
//  amount paid to employee. Reuse this class to calculate the amount to be paid to 
//  WeeklyEmployeed and HourlyEmployee according to no. of hours and total hours 
//  for HourlyEmployee and no. of weeks and total weeks for WeeklyEmployee. 
abstract class Employee{
    abstract float getAmount();
}
class w_emp extends Employee{
    int n;
    int t;
    int amt;
    w_emp(int x,int y,int z){
        n=x;
        t=y;
        amt=z;
    }
    float getAmount(){
        return ((float)n/t)*amt;
    }
}
class h_emp extends Employee{
    int n;
    int t;
    int amt;
    h_emp(int x,int y,int z){
        n=x;
        t=y;
        amt=z;
    }
    float getAmount(){
        return ((float)n/t)*amt;
    }
}
class second{
    public static void main(String args[]){
        w_emp w=new w_emp(3,6,1000);
        System.out.println(w.getAmount());
        h_emp h=new h_emp(4,8,100);
        System.out.println(h.getAmount());
    }
}