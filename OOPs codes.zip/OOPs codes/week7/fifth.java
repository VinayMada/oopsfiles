interface fare{
    void getAmount(int n);
}
class bus implements fare{
    public void getAmount(int n){
        System.out.println("Fare paid to the bus is "+n);
    }
}
class train implements fare{
    public void getAmount(int n){
        System.out.println("Fare paid to the train is "+n);
    }
}
class fifth{
    public static void main(String[] args) {
        bus b=new bus();
        b.getAmount(500);
        train t=new train();
        t.getAmount(200);
    }
}