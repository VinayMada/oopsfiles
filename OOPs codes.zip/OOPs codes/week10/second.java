import java.lang.Thread;
class consumer extends Thread{
    boolean status=false;
    public void run(){
        for(int i=0;i<5;i++){
            try{
                Thread.sleep(10);
            }
            catch(Exception e){
                System.out.println(e);
            }
            if(i==2) status=true;
            System.out.println("Status of production is: "+status);
        }
    }
}
class second{
    public static void main(String[] args) {
        consumer c=new consumer();
        Thread  t=new Thread(c);
        t.start();
    }
}