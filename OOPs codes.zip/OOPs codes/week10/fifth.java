import java.util.Scanner;

class trainrs{
    int available=10;
    
    void bookticket(int req){
        if(req>available){
            System.out.println("No berths available");
        }
        else{
            available-=req;
            System.out.println("Ticket is booked");
            System.out.println("Available tickets are "+available);
        }
    }
}
class trainthread extends Thread{
    int req;
    trainrs tr;
    public trainthread(int req,trainrs tr){
        this.req=req;
        this.tr=tr;
    }
    
    public void run(){

        tr.bookticket(req);
    }
}
class fifth{
    public static void main(String[] args) {
        trainrs t=new trainrs();
        int n;
        Scanner sc=new Scanner(System.in);
        n=sc.nextInt();
        for(int i=0;i<n;i++){
            int req=sc.nextInt();
            Thread t1=new trainthread(req,t);
            t1.setName("Person"+(i+1));
            t1.start();
        }
    }
}