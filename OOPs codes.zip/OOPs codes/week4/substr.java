class substr{
    public static void main(String[] args) {
        String main_s="Hello World";
        String sub_s="orl";
        int m=main_s.length();
        int n=sub_s.length(),flag=0;
        for(int i=0;i<m-n+1;i++){
            int c=0;
            for(int j=0;j<n;j++){
                if(main_s.charAt(i+j)!=sub_s.charAt(j)) break;
                else c++;
            }
            if(c==n){
                System.out.println("string matched");
                flag=1;
                break;
            }
        }
        if(flag==0) System.out.println("Not matched");
    }
}