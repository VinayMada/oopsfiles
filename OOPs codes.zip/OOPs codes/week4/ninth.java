import java.util.*;
class upperstr{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string:");
		String s=sc.next();
		System.out.println("Uppercase string is "+s.toUpperCase());
		System.out.println("Lowercase string is "+s.toLowerCase());
	}
}