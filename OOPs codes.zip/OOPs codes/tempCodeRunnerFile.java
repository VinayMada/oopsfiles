class ourexception extends Exception{
    ourexception(String s){
        super(s);
    }
}
class sixth{
    public static void main(String args[]){
        try{
            throw new ourexception("hello");
        }
        catch(ourexception e){
            System.out.println(e);
        }
    }
}