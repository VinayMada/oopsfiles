import java.util.*;
import java.lang.*;
class trainreserv{
    int b1=70,b2=70,s1=70,s2=70;
    int b1s[]=new int[70];
    int b2s[]=new int[70];
    int s1s[]=new int[70];
    int s2s[]=new int[70];
    void book_ticket(int tickets,String berth,String coach) throws Exception{
        if(coach.equals("sleeper")&&(berth.equals("b1")||berth.equals("b2"))){
            throw new Exception("You may be an Agent");
        }
        else if(coach.equals("sleeper")&&(berth.equals("s1")||berth.equals("s2"))){
            if(berth.equals("s1")){
                if(tickets>6){
                    throw new Exception("You may be an Agent");
                }
                else{
                    Random r=new Random();
                    for(int i=0;i<tickets;i++){
                        System.out.println("Allotted ticket "+(((int)(Math.random()*70))+1));
                    }
                }
            }
            else if(berth.equals("s2")){
                if(tickets>6){
                    throw new Exception("You may be an Agent");
                }
                else{
                    Random r=new Random();
                    for(int i=0;i<tickets;i++){
                        System.out.println("Allotted ticket "+(((int)(Math.random()*70))+1));
                    }
                }
            }
        }
        else if(coach.equals("AC")&&(berth.equals("s1")||berth.equals("s2"))){
            throw new Exception("You may be an Agent");
        }
        else if(coach.equals("AC")&&(berth.equals("b1")||berth.equals("b2"))){
            if(berth.equals("b1")){
                if(tickets>6){
                    throw new Exception("You may be an Agent");
                }
                else{
                    
                    for(int i=0;i<tickets;i++){
                        System.out.println("Allotted ticket "+(((int)(Math.random()*70))+1));
                    }
                }
            }
            else if(berth.equals("b2")){
                if(tickets>6){
                    throw new Exception("You may be an Agent");
                }
                else{
                    Random r=new Random();
                    for(int i=0;i<tickets;i++){
                        System.out.println("Allotted ticket "+(((int)(Math.random()*70))+1));
                    }
                }
            }
        }
    }
}
class fifth{
    public static void main(String args[]){
        System.out.println((((int)(Math.random()*70))+1));
        try{
            Scanner sc=new Scanner(System.in);
            String coach=sc.next();
            String berth=sc.next();
            int tickets=sc.nextInt();
            trainreserv t=new trainreserv();
            t.book_ticket(tickets,berth,coach);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}