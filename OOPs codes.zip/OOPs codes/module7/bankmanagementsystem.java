import bank.*;
import java.util.*;
class bankmgt implements bank.banksystem{
    String Un="vinay";
    String pd="vinay";
    double balance=5000;
    public void credentialsCheck(String Username,String password) throws Exception{
        if(Un.equals(Username)){
            if(pd.equals(password)){
                return;
            }
            else{
                throw new Exception("Username and Password mismatch");
            }
        }
        else{
            throw new Exception("Username and Password mismatch");
        }
    }
    public void credit(double amount){
        balance+=amount;
        return;
    }
    public void debit(double amount) throws Exception{
        if(amount>balance){
            throw new Exception("Debit amount exceeds balance");
        }
        else balance-=amount;
    }
    public void displayBalance(){
        System.out.println("Available balance= "+balance);
    }
    public void exit(){
        System.exit(0);
    }
}
class bankmanagementsystem{
    public static void main(String args[]){
        bankmgt b=new bankmgt();
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the username and password:");
        int count=0;
        while(true){
            try{
                if(count>0){
                    System.out.println("Re-enter the username and password:");
                }
                String uname=sc.next();
                String pass=sc.next();
                b.credentialsCheck(uname, pass);
                break;
            }
            catch(Exception e){
                count++;
                System.out.println(e.getMessage());
            }
        }
        while(true){
            System.out.println("For credit press 1 \n For debit press 2 \n For displaying Balance press 3 \n For exit press 4:");
            int nex=sc.nextInt();
            if(nex==1){
                System.out.println("Enter amount to be credited:");
                double amt=sc.nextDouble();
                b.credit(amt);
                
            }
            else if(nex==2){
                System.out.println("Enter amount to be debited:");
                double amt=sc.nextDouble();
                try{
                    b.debit(amt);
                }
                catch(Exception e){
                    System.out.println(e.getMessage());
                }
            }
            else if(nex==3){
                b.displayBalance();
            }
            else if(nex==4){
                b.exit();
            }
        }
    }
}