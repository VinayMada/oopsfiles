package audit;
public interface calc{
    abstract void taxChecker(double totalincome)throws Exception;
    abstract void taxPaid(double tax);
    abstract void healthex(double amt);
    abstract void homeex(double amt);
    abstract void vehicleex(double amt);
    abstract void pfex(double amt);
    abstract void miscex(double amt);
}