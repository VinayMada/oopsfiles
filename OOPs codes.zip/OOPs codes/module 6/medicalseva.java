package M_Seva;
import M_Seva.*;
import java.util.*;
public class medicalseva{
    public void intialize(){
        System.out.println("Welcome to M-Seva!");
        Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    String diseases[]=new String[n];
    for(int i=0;i<n;i++){
        diseases[i]=sc.nextLine();
    }
    M_Seva.diseases d=new M_Seva.diseases();
    d.search(diseases,n);
    }
}