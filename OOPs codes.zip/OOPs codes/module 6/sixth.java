import M_Seva.*;
class sixth{
    public static void main(String args[]){
        M_Seva.medicalseva m=new M_Seva.medicalseva();
        m.intialize();
    }
}