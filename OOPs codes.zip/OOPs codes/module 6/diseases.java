package M_Seva;
import java.util.*;
public class diseases{
    String ap[]=new String[]{"Stomach ache","vomiting","low eye sight","muscle ache","fever"};
    String a[]=new String[]{"Stomach ache","vomiting","low eye sight","fatigue","fever"};
    String bc[]=new String[]{"Stomach ache","vomiting","low eye sight","skin allergy","low bp"};
    String pc[]=new String[]{"Stomach ache","vomiting","low eye sight","fatigue","fever"};
    public void search(String diseases[],int n){
        Set<String> h=new HashSet<String>();
        for(int i=0;i<n;i++){
            for(int j=0;j<5;j++){
                if(diseases[i].equals(ap[j])){
                    h.add("ap");
                }
            }
            for(int j=0;j<5;j++){
                if(diseases[i].equals(a[j])){
                    h.add("a");
                }
            }
            for(int j=0;j<5;j++){
                if(diseases[i].equals(bc[j])){
                    h.add("bc");
                }
            }
            for(int j=0;j<5;j++){
                if(diseases[i].equals(pc[j])){
                    h.add("pc");
                }
            }
        }
        for(String hs:h){
            System.out.println(hs);
        }
    }
}