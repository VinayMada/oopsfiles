import java.util.Arrays;
class sixth{
    public static void main(String[] args) {
        Arrays.sort(args);
        System.out.println(Arrays.toString(args));
    }
}