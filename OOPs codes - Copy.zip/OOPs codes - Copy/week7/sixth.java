interface Studentfee{
    void getAmount(int amt);
    void getFirstName(String f_name);
    void getLastName(String l_name);
    void getAddress(String add);
    void getContact(int num);
}
class hosteler implements Studentfee{
    public void getAmount(int amt){
        System.out.println("Amount paid by the hosteler= "+amt);
    }
    public void getFirstName(String f_name){
        System.out.println("first name of the hosteler= "+f_name);
    }
    public void getLastName(String l_name){
        System.out.println("last name of the hosteler= "+l_name);
    }
    public void getAddress(String add){
        System.out.println("Address of the hosteler= "+add);
    }
    public void getContact(int num){
        System.out.println("contact of the hosteler= "+num);
    }
}
class non_hosteler implements Studentfee{
    public void getAmount(int amt){
        System.out.println("Amount paid by the non-hosteler= "+amt);
    }
    public void getFirstName(String f_name){
        System.out.println("first name of the non-hosteler= "+f_name);
    }
    public void getLastName(String l_name){
        System.out.println("last name of the non-hosteler= "+l_name);
    }
    public void getAddress(String add){
        System.out.println("Address of the non-hosteler= "+add);
    }
    public void getContact(int num){
        System.out.println("contact of the non-hosteler= "+num);
    }
}
class sixth{
    public static void main(String[] args) {
        hosteler h=new hosteler();
        h.getAmount(70000);
        non_hosteler nh=new non_hosteler();
        nh.getAmount(1000);
    }
}