class methods {
	static int Multiply(int a, int b)
	{
		return a * b;
	}
	static int Multiply(int a, int b, int c)
	{
		return a * b * c;
	}
}
class overloading{
	public static void main(String[] args)
	{
		System.out.println(methods.Multiply(2, 4));
		System.out.println(methods.Multiply(2, 7, 3));
	}
}
// import java.util.*;
// class Parent {
// 	void Print()
// 	{
// 		System.out.println("parent class");
// 	}
// }
// class subclass1 extends Parent {
// 	void Print() { System.out.println("subclass1"); }
// }
// class subclass2 extends Parent {

// 	void Print()
// 	{
// 		System.out.println("subclass2");
// 	}
// }
// class overriding {
// 	public static void main(String[] args)
// 	{
// 		Parent a;
// 		a = new subclass1();
// 		a.Print();
// 		a = new subclass2();
// 		a.Print();
// 	}
// }