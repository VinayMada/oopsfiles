// . Write a program to rethrow an exception – Define methods one() & two(). Method two()
//  should initially throw an exception. Method one() should call two(), catch the exception 
//  and rethrow it Call one() from main() and catch the rethrown
class trycatch3{
	 void two() throws Exception{
		throw new Exception("Throwed exception from method two");
	}
	  void one() throws Exception{
		try{
			two();
		}
		catch(Exception e){
			System.out.println(e+"  Exception caught in method one()");
			throw new Exception(e);
		}
	}
	
}
class third{
	public static void main(String args[]){
		trycatch3 t=new trycatch3();
		try{
			t.one();
		}
		catch(Exception e){
			System.out.println(e+"  Exception caught in main");
		}
	}
}