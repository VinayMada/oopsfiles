 import java.util.*;
 class first{
 	public static void main(String args[]){
 		try{
 			throw new Exception("throwed a exception");
 		}
 		catch(Exception e){
 			System.out.println(e.getMessage());
 		}
 		finally{
 			System.out.println("IN finally block");
 		}
 	}
 }