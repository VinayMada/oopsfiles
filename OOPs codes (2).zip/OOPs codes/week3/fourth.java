import java.util.Random;

public class fourth {

    public static void main(String[] args) {
        int numberOfAttempts = 10;
        int successfulAttempts = 0;

        for (int i = 0; i < numberOfAttempts; i++) {
            // Roll the dice
            int dice1 = rollDie();
            int dice2 = rollDie();

            System.out.println("Attempt " + (i + 1) + ": Dice 1: " + dice1 + ", Dice 2: " + dice2);

            // Check if it's a successful attempt
            if (dice1 == dice2) {
                System.out.println("Successful attempt!");
                successfulAttempts++;
            }

            // Delay for 10000 ms (10 seconds)
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("\nNumber of successful attempts: " + successfulAttempts);
    }

    private static int rollDie() {
        // Simulate rolling a six-sided die
        Random random = new Random();
        return random.nextInt(6) + 1;
    }
}

