class Vehicle {
  String vehicleNumber;
  String insuranceNumber;
  String color;

Vehicle(String vehicleNumber, String insuranceNumber, String color) {
this.vehicleNumber = vehicleNumber;
this.insuranceNumber = insuranceNumber;
this.color = color;
}

  void getConsumption() {
// Implementation for getting consumption
}

  void displayConsumption() {
// Implementation for displaying consumption
}
}
class TwoWheeler extends Vehicle {
  TwoWheeler(String vehicleNumber, String insuranceNumber, String color) {
super(vehicleNumber, insuranceNumber, color);
}

  void maintenance() {
// Implementation for maintenance of TwoWheeler
}

  void average() {
// Implementation for calculating average of TwoWheeler
}
}
class FourWheeler extends Vehicle {
  FourWheeler(String vehicleNumber, String insuranceNumber, String color) {
super(vehicleNumber, insuranceNumber, color);
}

  void maintenance() {
// Implementation for maintenance of FourWheeler
}

  void average() {
// Implementation for calculating average of FourWheeler
}
}
  class fifth {
  public static void main(String[] args) {
TwoWheeler twoWheeler = new TwoWheeler("TW123", "INS123", "Red");
twoWheeler.getConsumption();
twoWheeler.displayConsumption();
twoWheeler.maintenance();
twoWheeler.average();

FourWheeler fourWheeler = new FourWheeler("FW123", "INS456", "Blue");
fourWheeler.getConsumption();
fourWheeler.displayConsumption();
fourWheeler.maintenance();
fourWheeler.average();
}
}
