interface vehicle{
    void getColor(String color);
    void getNumber(int number);
    void getConsumption(int l,int fuel_cost);
}
class two_w implements vehicle{
    public void getColor(String color){
        System.out.println("color of two wheeler= "+color);
    }
    public void getNumber(int number){
        System.out.println("Number of two wheeler= "+number);
    }
    public void getConsumption(int l,int fuel_cost){
        System.out.println("Consumption of two wheeler= "+l*fuel_cost);
    }
}
class four_w implements vehicle{
    public void getColor(String color){
        System.out.println("color of four wheeler= "+color);
    }
    public void getNumber(int number){
        System.out.println("Number of four wheeler= "+number);
    }
    public void getConsumption(int l,int fuel_cost){
        System.out.println("Consumption of four wheeler= "+l*fuel_cost);
    }
}
class fourth{
    public static void main(String[] args) {
        two_w t=new two_w();
        t.getColor("black");
        t.getNumber(7493);
        t.getConsumption(2,120);
        four_w f=new four_w();
        f.getColor("white");
        f.getNumber(45782);
        f.getConsumption(5,110);
    }
}