import java.util.*;
class third{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		char c=sc.next().charAt(0);
		int count=0;
        int index=s.indexOf(c);
        while(index!=-1){
            count++;
            index=s.indexOf(c,index+1);
        }
        System.out.println("No of occurrances of character "+c+" = "+count);
	}
}