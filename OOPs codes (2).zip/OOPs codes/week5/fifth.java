import java.util.*;
class thiss{
	int a;
	void initial(int a){
		this.a=a;
		System.out.println(this.a);
	}
	public static void main(String args[]){
		thiss t=new thiss();
		t.initial(9);
	}
}
// import java.util.*; 
// public class stat { 
// 	static int a = 40; 
// 	int b = 50; 
// 	void simpleDisplay() 
// 	{ 
// 		System.out.println(a); 
// 		System.out.println(b); 
// 	} 
// 	static void staticDisplay() 
// 	{ 
// 	System.out.println(a); 
// 	} 
// 	public static void main(String[] args) 
// 	{ 
// 		stat obj = new stat(); 
// 		obj.simpleDisplay(); 
// 		staticDisplay(); 
// 	} 
// }