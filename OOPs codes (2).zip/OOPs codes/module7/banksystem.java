package bank;
public interface banksystem{
    abstract void credentialsCheck(String Username,String password) throws Exception;
    abstract void credit(double amount);
    abstract void debit(double amount)throws Exception;
    abstract void displayBalance();
    abstract void exit();
}