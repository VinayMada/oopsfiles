import java.util.*;
class first{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        try{
            int c=sc.nextInt();
        }
        catch(InputMismatchException e){
            System.out.println(e);
        }
    }
}