import audit.*;
import java.util.*;
class calculation implements audit.calc{
    double totalexpenditure=0;
    double taxPaid=0;
    public void taxChecker(double totalincome) throws Exception{
        if((totalincome-totalexpenditure)*0.1!=taxPaid) {
            throw new Exception("Fraud");
        }
        else{
            System.out.println("Everything is fine");
        }
    }
    public void taxPaid(double tax){
        taxPaid=tax;
    }
    public void healthex(double amt){
        totalexpenditure+=amt;
    }
    public void homeex(double amt){
        totalexpenditure+=amt;
    }
    public void vehicleex(double amt){
        totalexpenditure+=amt;
    }
    public void pfex(double amt){
        totalexpenditure+=amt;
    }
    public void miscex(double amt){
        totalexpenditure+=amt;
    }
}
class third{
    public static void main(String args[]){
        calculation c=new calculation();
        Scanner sc=new Scanner(System.in);
        double home=sc.nextDouble();
        double health=sc.nextDouble();
        double vehicle=sc.nextDouble();
        double pf=sc.nextDouble();
        double misc=sc.nextDouble();
        c.homeex(home);
        c.healthex(health);
        c.vehicleex(vehicle);
        c.pfex(pf);
        c.miscex(misc);
        double tax=sc.nextDouble();
        c.taxPaid(tax);
        double totalincome=sc.nextDouble();
        try{
            c.taxChecker(totalincome);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            System.out.println("Amount to be paid="+(totalincome-c.totalexpenditure)*0.1);
        }
    }

}