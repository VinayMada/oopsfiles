import complex.*;
class fifth{
    public static void main(String args[]){
        complex.Arith one=new complex.Arith(10,8);
        complex.Arith two=new complex.Arith(3,7);
        complex.Arith three=new complex.Arith();
        complex.Arith fourth=new complex.Arith();
        three.add(one,two);
        fourth.sub(one,two);
    }
}