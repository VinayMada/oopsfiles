// In the "admission" package

package admission;

public interface AdmissionCriteria {
    boolean checkEligibility(int mathsMarks, int physicsMarks, int chemistryMarks, int englishMarks);
}

