// In the "reservation_cost" package

package reservation_cost;

public class ReservationCalculator implements ReservationCost {

    @Override
    public double totalFare(Passenger[] passengers) {
        double totalFare = 0;

        for (Passenger passenger : passengers) {
            if (passenger instanceof ChildPassenger) {
                // Children travel for free
                // Do nothing
            } else if (passenger instanceof StudentPassenger) {
                // Students get a 30% discount
                totalFare += 0.7 * calculateActualFare();
            } else if (passenger instanceof SeniorCitizenPassenger) {
                // Senior citizens get a 50% discount
                totalFare += 0.5 * calculateActualFare();
            } else if (passenger instanceof CitizenPassenger) {
                // Citizens pay the actual fare with no discount
                totalFare += calculateActualFare();
            }
        }

        return totalFare;
    }

    // Placeholder method to calculate the actual fare (customize as needed)
    private double calculateActualFare() {
        // Your logic to calculate the actual fare
        return 100; // Placeholder value, replace it with your logic
    }
}
