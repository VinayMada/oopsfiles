import reservation_cost.*;

public class ReservationApp {
    public static void main(String[] args) {
        // Create an array of passengers
        Passenger[] passengers = {
                new ChildPassenger(),
                new StudentPassenger(),
                new SeniorCitizenPassenger(),
                new CitizenPassenger()
        };

        // Calculate the total fare using the ReservationCalculator
        ReservationCost reservationCalculator = new ReservationCalculator();
        double totalFare = reservationCalculator.totalFare(passengers);

        // Print the total fare
        System.out.println("Total Fare: " + totalFare);
    }
}
