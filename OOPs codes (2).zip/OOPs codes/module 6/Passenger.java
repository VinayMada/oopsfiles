// In the "reservation_cost" package

package reservation_cost;

class Passenger {
    // Common attributes for all types of passengers
}

class ChildPassenger extends Passenger {
    // Additional attributes/methods specific to children
}

class StudentPassenger extends Passenger {
    // Additional attributes/methods specific to students
}

class CitizenPassenger extends Passenger {
    // Additional attributes/methods specific to citizens
}

class SeniorCitizenPassenger extends Passenger {
    // Additional attributes/methods specific to senior citizens
}
