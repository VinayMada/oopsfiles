package admission;
public class EngineeringAdmission implements AdmissionCriteria {
    @Override
    public boolean checkEligibility(int mathsMarks, int physicsMarks, int chemistryMarks, int englishMarks) {
        // Check if the student satisfies the admission criteria
        return (mathsMarks >= 90 && physicsMarks >= 95 && chemistryMarks >= 70 && englishMarks >= 80
                && calculateTotalPercentage(mathsMarks, physicsMarks, chemistryMarks, englishMarks) >= 80);
    }

    private double calculateTotalPercentage(int mathsMarks, int physicsMarks, int chemistryMarks, int englishMarks) {
        // Your logic to calculate total percentage
        return (mathsMarks + physicsMarks + chemistryMarks + englishMarks) / 4.0;
    }
}
