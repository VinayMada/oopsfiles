package TVRemote;
public class Television implements RemoteControl {
    private boolean isOn;
    private int currentChannel;

    public Television() {
        this.isOn = false;
        this.currentChannel = 0;
    }

    @Override
    public void switchOn() {
        if (!isOn) {
            System.out.println("Welcome to TATA SKY");
            isOn = true;
        } else {
            System.out.println("TV is already ON.");
        }
    }

    @Override
    public void switchOff() {
        if (isOn) {
            System.out.println("Switching OFF the TV.");
            isOn = false;
        } else {
            System.out.println("TV is already OFF.");
        }
    }

    @Override
    public void playStarSports() {
        if (isOn) {
            currentChannel = 2;
            System.out.println("Playing Star Sports channel");
        } else {
            System.out.println("Please switch ON the TV first.");
        }
    }

    @Override
    public void playNGC() {
        if (isOn) {
            currentChannel = 3;
            System.out.println("Playing NGC channel");
        } else {
            System.out.println("Please switch ON the TV first.");
        }
    }

    @Override
    public void playDiscovery() {
        if (isOn) {
            currentChannel = 4;
            System.out.println("Playing Discovery channel");
        } else {
            System.out.println("Please switch ON the TV first.");
        }
    }

    @Override
    public void playStarMovies() {
        if (isOn) {
            currentChannel = 5;
            System.out.println("Playing Star Movies channel");
        } else {
            System.out.println("Please switch ON the TV first.");
        }
    }
}

