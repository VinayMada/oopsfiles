// In the "TV-Remote" package

package TVRemote;

public interface RemoteControl {
    void switchOn();
    void switchOff();
    void playStarSports();
    void playNGC();
    void playDiscovery();
    void playStarMovies();
}

