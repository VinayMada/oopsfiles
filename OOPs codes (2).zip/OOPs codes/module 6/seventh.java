import TVRemote.Television;

public class seventh {
    public static void main(String[] args) {
        Television myTV = new Television();

        myTV.switchOn();
        myTV.playStarSports();
        myTV.playNGC();
        myTV.playDiscovery();
        myTV.playStarMovies();
        myTV.switchOff();
    }
}
