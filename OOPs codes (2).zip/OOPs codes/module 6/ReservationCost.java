// In the "reservation_cost" package

package reservation_cost;

public interface ReservationCost {
    double totalFare(Passenger[] passengers);
}
