class TooManyLinesException extends Exception{
    public TooManyLinesException(String s){
        super(s);
    }
}
class Print{
    int count=0;
    void print(String s) throws TooManyLinesException{
        count++;
        if(count>25){
            throw new TooManyLinesException("Lines exceeded 25");
           
        }
        else
        System.out.println(s);
    }
    void println(String s) throws TooManyLinesException{
        count++;
        if(count>25){
            throw new TooManyLinesException("Lines exceeded 25");
           
        }
        else
        System.out.println(s);
    }
}
class mt3{
    public static void main(String[] args) {
        Print p=new Print();
    for(int i=0;i<27;i++){
        try{
            p.print("hello");
            p.println("hi");
        }
        catch(TooManyLinesException e){
            System.out.println(e.getMessage());
        }
    }
    }
}
