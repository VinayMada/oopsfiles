import java.lang.*;
class traffic extends Thread{
    public void run(){
        int rc=1,yc=0,gc=0;
        while(true){
            try{
                Thread.sleep(10000);
            }
            catch(Exception e){
                System.out.println(e);
            }
            if(rc==1){
                System.out.println("Red light is glowing");
                rc=0;
                yc=1;
                continue;
            }
            else if(yc==1){
                System.out.println("Yellow light is glowing");
                yc=0;
                gc=1;
                continue;
            }
            else if(gc==1){
                System.out.println("Green light is glowing");
                gc=0;
                rc=1;
                continue;
            }
        }
    }
}
class third{
    public static void main(String[] args) {
        traffic t=new traffic();
        Thread t1=new Thread(t);
        t1.start();
    }
}