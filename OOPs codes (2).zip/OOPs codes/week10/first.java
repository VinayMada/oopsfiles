import java.lang.Thread;
class myThread extends Thread{
    public void run(){
        System.out.println("In a run method"+Thread.currentThread().getName());
        for(int i=0;i<4;i++){
            System.out.println(Thread.currentThread().getName());
        }
    }
}
class first{
    public static void main(String[] args) {
        myThread t=new myThread();
        Thread thread=new Thread(t);
        thread.start();
    }
}