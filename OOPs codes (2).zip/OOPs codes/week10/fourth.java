import java.util.Scanner;

class theatre extends Thread{
    boolean ticket;
    public void run(){
        System.out.println(Thread.currentThread().getName());
    }
}
class fourth{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        theatre t=new theatre();
        int n=sc.nextInt();
        for(int i=0;i<n;i++){
            Thread t1=new Thread(t);
            t.ticket=true;
            t1.setName("person"+(i+1));
            t1.start();
        }
    }
}